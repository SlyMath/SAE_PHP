<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Playlist extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Model_user');
		$this->load->model('Model_playlist');
	}
	public function index(){
        
		$this->load->view('layout/header');
		$this->load->view('playlist_list');
		$this->load->view('layout/footer');
	}
}

