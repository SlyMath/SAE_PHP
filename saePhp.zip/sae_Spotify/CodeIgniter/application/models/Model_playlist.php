<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_playlist extends CI_Model {
    public function __construct(){
        $this->load->database();
    }

    public function getPlaylist(){
        $query = $this->db->get('playlist');
        return $query->result();
    }

    public function getPlaylistById($id) {
        $userId = $this->session->userdata('user_id');
        
        $this->db->where('id', $id);
        $this->db->where('user_id', $userId);
        $query = $this->db->get('playlist');
        
        return $query->result();
    }
    

    public function getPlaylistByNameAZ() {
        $this->db->order_by('name', 'ASC');
        $query = $this->db->get_where('playlist', array('user_id' => $this->session->userdata('user_id')));
        return $query->result();
        }

    public function getPlaylistByNameZA() {
        $this->db->order_by('name', 'DESC');
        $query = $this->db->get_where('playlist', array('user_id' => $this->session->userdata('user_id')));
        return $query->result();
        }

    public function search($input) {
        $input = '%' . $input . '%';
        $userid = $this->session->userdata('user_id');
        $sql = "SELECT * FROM playlist WHERE user_id = ? AND nom LIKE ?";
        $query = $this->db->query($sql, array($userid, $input));
        return $query->result();
    }

    public function addPlaylist($nom, $jpeg) {

        $defaultPath = 'assets/images/default_cover.jpg';
        if ($jpeg == null) {
            $jpegData = file_get_contents($defaultPath);
        } else {
            $jpegData = file_get_contents($jpeg);
        }

        $data = array(
            'nom' => $name,
            'user_id' => $this->session->userdata('user_id'),
            'jpeg' => $jpegData
        );

        $this->db->insert('playlist', $data);

    }
}
?>

