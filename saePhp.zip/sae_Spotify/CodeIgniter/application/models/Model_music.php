<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');                                             

class Model_music extends CI_Model {
	public function __construct(){
		$this->load->database();
	}

	public function getAlbums(){
		$query = $this->db->query(
			"SELECT album.name,album.id,year,artist.name as artistName, genre.name as genreName,jpeg 
			FROM album 
			JOIN artist ON album.artistid = artist.id
			JOIN genre ON genre.id = album.genreid
			JOIN cover ON cover.id = album.coverid
			ORDER BY year
			"
		);
	return $query->result();
	}

	public function getAlbumsAZ() {
        $query = $this->db->query(
			"SELECT album.name,album.id,year,artist.name as artistName, genre.name as genreName,jpeg 
			FROM album 
			JOIN artist ON album.artistid = artist.id
			JOIN genre ON genre.id = album.genreid
			JOIN cover ON cover.id = album.coverid
			ORDER BY album.name;
			"
		);
        return $query->result();
    }

	public function getAlbumsZA() {
		$query = $this->db->query(
		"SELECT album.name,album.id,year,artist.name as artistName, genre.name as genreName,jpeg 
				FROM album 
				JOIN artist ON album.artistid = artist.id
				JOIN genre ON genre.id = album.genreid
				JOIN cover ON cover.id = album.coverid
				ORDER BY album.name DESC"
			);
			return $query->result();
		}
	
	public function search($input) {
        $input = '%' . $input . '%';
        $sql = "SELECT album.name, album.id, year, artist.name AS artistName, genre.name AS genreName, jpeg 
			FROM album 
			JOIN artist ON album.artistid = artist.id
			JOIN genre ON genre.id = album.genreid
			JOIN cover ON cover.id = album.coverid
			WHERE album.name LIKE ?
			ORDER BY year";
        $query = $this->db->query($sql, array($input));
        return $query->result();
    }
}



// LET ME WORK IN PISSSSSS !!!