<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <ul class="menu">
            <li><?=anchor('register','Register');?></li>
            <li><?=anchor('albums','Menu');?></li>
        </ul>
        <?php if(isset($error) && !empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="<?php echo site_url('login/login'); ?>" method="post">
            <label for="email">Email:</label>
            <input type="text" id="email" name="email">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
            <input type="submit" value="Connexion">
        </form>
    </div>
</body>
</html>
