<!doctype html>
<html lang="en" class="has-navbar-fixed-top">
	<head>
		<meta charset="UTF-8" />
		<title>MUSIC APP</title>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css"
/>
<style>
  .btn-logout {
    font-size: 14px; /* Taille de la police */
    padding: 3px 15px; /* Espacement interne */
}
section.list
{
	display : flex;
	justify-content : space-between;
	flex-wrap:wrap;
}
section.list > div 
{
width : 30%;
}
section.list img {
	display:inline-block;

}
.short-text {
	overflow: hidden;
	white-space: nowrap;
	text-overflow: ellipsis;
}
</style>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<main class='container'>
			<nav>
  <ul>
    <li><strong>Music APP</strong></li>
  </ul>
  <ul>
  <li><?=anchor('albums','Albums');?></li>
  <li><?=anchor('artistes','Artists');?></li>
  <?php if ($this->Model_user->is_logged_in()) : ?>     
            <li><?=anchor('playlist','Playlist');?></li>
            <li><strong><?php echo $this->session->userdata('user_name');?></strong></li> 
        <?php endif; ?>
  
  <?php if ($this->Model_user->is_logged_in()) : ?>
    <form action="<?= site_url('login/logout') ?>" method="post">
        <button type="submit" class="btn-logout"><i class="fa fa-sign-out">Logout</i></button>
    </form>
  <?php endif; ?>
  <?php if ($this->Model_user->is_logged_in()) : ?>
            <!-- Si l'utilisateur est connecté, afficher son nom d'utilisateur -->
            <li><strong><?= $this->session->userdata('username'); ?></strong></li>
        <?php else : ?>
            <!-- Sinon, afficher un lien de connexion -->
            <li><?= anchor('login', 'Login'); ?></li>
        <?php endif; ?>
        
  </ul>
</nav>
