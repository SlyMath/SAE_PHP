<nav>
    <select onchange="location = this.value;">
        <option value="">Trier par</option>
        <option value="<?php echo site_url('albums/sortSongAZ/'.$album_id); ?>">De A-Z</option>
        <option value="<?php echo site_url('albums/sortSongZA/'.$album_id); ?>">De Z-A</option>
    </select>
</nav>


<h5>Albums list</h5>
<section class="list">
<?php
foreach($tracks as $track){
	echo "<div><article>";
	echo "<header class='short-text'>";
	echo "$track->song_name";
	echo "</header>";
	echo "</footer></article></div>";
}
?>
</section>
