<!DOCTYPE html>
<html>
<head>
    <title>Liste des fichiers</title>
</head>
<style type="/css/style.css"></style>
<body>


<h1>Liste des fichiers</h1>
<ul>
    <?php
    // Chemin du répertoire contenant les fichiers
    $directory = "./";

    // Ouvre le répertoire
    if ($handle = opendir($directory)) {
        // Initialize an array to store directory names
        $directories = array();

        // Parcours chaque fichier du répertoire
        while (($file = readdir($handle)) !== false) {
            // Exclut les fichiers spéciaux
            if ($file != "." && $file != ".." && $file != "index.php" && is_dir($file) && $file != "css") {
                // Add directory name to the array
                $directories[] = $file;
            }
        }
        // Ferme le gestionnaire de répertoire
        closedir($handle);

        // Sort the array of directory names
        sort($directories);

        // Iterate over the sorted array and display the directories
        foreach ($directories as $dir) {
            echo "<li><a href='$dir'>$dir</a></li>";
        }
    }
    ?>
</ul>

<div class="container">
    <div class="signature">
        Damien Riera
    </div>
</div>

</body>
</html>
