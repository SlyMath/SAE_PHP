<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Model_user');
    }

    public function index(){
        $this->load->view('login');
        $this->load->view('layout/footer');
    }

    public function login() {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $password = password_hash($password, PASSWORD_BCRYPT);
    
        // Vérifier les informations d'identification
        if ($this->validate_credentials($email, $password)) {
            // Informations d'identification valides, créer une session
            $user_id = $this->get_user_id($email);
            $this->session->set_userdata('user_id', $user_id);
            redirect('albums'); // Rediriger vers la page de tableau de bord ou autre page après la connexion
        } else {
            // Informations d'identification invalides, afficher un message d'erreur
            $data['error'] = 'Nom d\'utilisateur ou mot de passe invalide.';
            $this->load->view('login', $data);
        }
    }

    public function validate_credentials($email, $password) {
        // Vérification des informations d'identification dans la base de données
        $query = $this->db->get_where('utilisateur', array('email' => $email, 'mot_de_passe' => $password));
        $user = $query->row();
        return ($user) ? true : false;
    }

    
}
?>