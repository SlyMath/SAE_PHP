<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_artist extends CI_Model {
    public function __construct(){
        $this->load->database();
    }

    public function getArtists(){
        $query = $this->db->get('artist');
        return $query->result();
    }

    public function getArtistById($id){
        $query = $this->db->get_where('artist', array('id' => $id));
        return $query->row();
    }

    public function getArtistByNameAZ() {
        $this->db->order_by('name', 'ASC');
        $query = $this->db->get('artist');
        return $query->result();
        }

    public function getArtistByNameZA() {
        $this->db->order_by('name', 'DESC');
        $query = $this->db->get('artist');
        return $query->result();
        }
    }
?>