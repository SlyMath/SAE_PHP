<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_user extends CI_Model {

    public function __construct() {
        parent::__construct();
        // Chargement de la base de données
        $this->load->database();
    }

    public function get_user_id($username) {
        // Récupération de l'ID de l'utilisateur à partir de la base de données en fonction du nom d'utilisateur
        $query = $this->db->get_where('utilisateurs', array('username' => $username));
        $user = $query->row();
        return ($user) ? $user->id : false;
    }

    public function is_logged_in() {
        return $this->session->has_userdata('user_id');
    }

}
?>
