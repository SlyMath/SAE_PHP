<h5>Artists list</h5>
<section class="artist-list">

<h5>Artists</h5>
<nav>
<a href="<?php echo site_url('artistes/sortAZ'); ?>">De A-Z</a>
<a href="<?php echo site_url('artistes/sortZA'); ?>">De Z-A</a>
</nav>

<section class="artist-list">
<?php
foreach($artists as $artist){
    echo "<div><article>";
    echo "<header class='short-text'>";
    echo anchor("artists/view/{$artist->id}", "{$artist->name}");
    echo "</header>";
    echo "</article></div>";
}
?>
</section>
</body>
</html>