<!doctype html>
<html lang="en" class="has-navbar-fixed-top">
	<head>
		<meta charset="UTF-8" />
		<title>MUSIC APP</title>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css"
/>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<main class='container'>
			<nav>
  <ul>
    <li><strong>Music APP</strong></li>
  </ul>
  <ul>
  <li><?=anchor('albums','Albums');?></li>
  <li><?=anchor('artistes','Artistes');?></li>
  <?php if ($this->Model_user->is_logged_in()) : ?>
            <!-- Si l'utilisateur est connecté, afficher son nom d'utilisateur -->
            <li><?=anchor('playlist','Playlist');?></li>
        <?php endif; ?>
  
  <?php if ($this->Model_user->is_logged_in()) : ?>
            <!-- Si l'utilisateur est connecté, afficher son nom d'utilisateur -->
            <li><strong><?= $this->session->userdata('username'); ?></strong></li>
        <?php else : ?>
            <!-- Sinon, afficher un lien de connexion -->
            <li><?= anchor('login', 'Login'); ?></li>
        <?php endif; ?>
  </ul>
</nav>
